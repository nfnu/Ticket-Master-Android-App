package com.example.nisha.nmtapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

public class UpdateAdapter extends RecyclerView.Adapter<UpdateAdapter.MyViewHolder>{

private List<Update> moviesList;



public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView dispname,artistname,update,type,uri,date;
    public MyViewHolder(View view) {
        super(view);
        view.setOnClickListener(this);
        dispname = (TextView) view.findViewById(R.id.dispname);
        artistname = (TextView) view.findViewById(R.id.artistname);
        update = (TextView) view.findViewById(R.id.update);
        type = (TextView) view.findViewById(R.id.type);
        uri = (TextView) view.findViewById(R.id.uri);
        date = (TextView) view.findViewById(R.id.date);
    }


    @Override
    public void onClick(View v) {
        Uri url = Uri.parse(uri.getText().toString());
        Intent intent = new Intent(Intent.ACTION_VIEW, url);
        v.getContext().startActivity(intent);
    }
}


    public UpdateAdapter(List<Update> moviesList) {
        this.moviesList = moviesList;
    }

    @Override
    public UpdateAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.update_list_row, parent, false);

        return new UpdateAdapter.MyViewHolder(itemView);
    }


    @Override
    public void onBindViewHolder(UpdateAdapter.MyViewHolder holder, int position) {
        Update movie = moviesList.get(position);
        holder.dispname.setText(movie.getDispname());
        holder.artistname.setText(movie.getArtistname());
        holder.update.setText(movie.getUpdate());
        holder.uri.setText(movie.getUri());
        holder.type.setText(movie.getType());
        holder.date.setText(movie.getDate());
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}


