package com.example.nisha.nmtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class EventDetail extends AppCompatActivity {
String id,fav,name,venue,url,artist1,artist2,segment,idd,keyw,category,dista,typed,otherloc,lat,lon,back,img1,date,time;
MenuItem heartfill,heart;
    SharedPreferences pref;
    String[] favs;
    String[] keys;
    StringBuilder key = new StringBuilder();
    StringBuilder favt = new StringBuilder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            try {
                id = extras.getString("id");
                date = extras.getString("date");
                time = extras.getString("time");
                img1 = extras.getString("img1");
                idd=id;
                fav = extras.getString("fav");
                name = extras.getString("name");
                venue = extras.getString("venue");
                url = extras.getString("url");
                artist1 = extras.getString("artist1");
                artist2 = extras.getString("artist2");
                segment = extras.getString("segment");
                keyw=extras.getString("keyw");
                category=extras.getString("category");
                dista=extras.getString("dista");
                typed=extras.getString("typed");
                otherloc=extras.getString("otherloc");
                back=extras.getString("back");
                lat=extras.getString("lat");
                lon=extras.getString("lon");
            }catch(NullPointerException  e) {
                Toast.makeText(this,"Exception",Toast.LENGTH_LONG).show();
            }

        }
        //Toast.makeText(this, keyw, Toast.LENGTH_SHORT).show();
        if (name.length()>23)
        getSupportActionBar().setTitle(name.subSequence(0,22)+" ...");
        else
        getSupportActionBar().setTitle(name);

        final TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Event"));
        tabLayout.addTab(tabLayout.newTab().setText("Artist(s)"));
        tabLayout.addTab(tabLayout.newTab().setText("Venue"));
        tabLayout.addTab(tabLayout.newTab().setText("Upcoming"));
        tabLayout.getTabAt(0).setIcon(R.drawable.info_outline);
        tabLayout.getTabAt(1).setIcon(R.drawable.artist);
        tabLayout.getTabAt(2).setIcon(R.drawable.venue);
        tabLayout.getTabAt(3).setIcon(R.drawable.upcoming);
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter1 adapter = new PagerAdapter1
                (getSupportFragmentManager(), tabLayout.getTabCount(),id,venue,artist1,artist2,segment);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_event, menu);
        heartfill=menu.findItem(R.id.heartfill);
        heart=menu.findItem(R.id.heart);
        //heartfill.setVisible(false);
        int i;
        pref = this.getSharedPreferences("MyPref", 0);
        if(pref.contains("key")) {
            String[] keys = pref.getString("key", "").split(",");
            for (i = 0; i < keys.length; i++) {
                if (keys[i].equals(idd)) {
                    heartfill.setVisible(true);
                    heart.setVisible(false);
                    break;
                }
            }
            if (i == keys.length) {
                heart.setVisible(true);
                heartfill.setVisible(false);
            }
        } else{
            heart.setVisible(true);
            heartfill.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.heart) {

            item.setVisible(false);
            heartfill.setVisible(true);
            heart.setVisible(false);
            Toast.makeText(this,
                    name+" was added to favorites",
                    Toast.LENGTH_LONG).show();


            SharedPreferences pref = this.getSharedPreferences("MyPref", 0);

            SharedPreferences.Editor editor = pref.edit();
            if(pref.contains("key")) {
                key.append(pref.getString("key", ""));
                key.append(idd).append(",");
            }
            else
                key.append(idd).append(",");
            editor.putString("key",key.toString() ); // Storing string
            editor.commit();

            pref = this.getSharedPreferences("MyPref", 0);

            editor = pref.edit();
            if(pref.contains("fav")) {
                favt.append(pref.getString("fav", ""));
            }
            favt.append(idd).append(",").append(name).append(",").append(venue).append(",").append(date).append(",").append(time).append(",").append(artist1).append(",").append(artist2).append(",").append(segment).append(",").append(img1).append(",").append(url).append(",");
            editor.putString("fav",favt.toString() );
            editor.commit();

             // commit changes
            fav="1";
            return true;
        }
        if (id == R.id.heartfill) {

            item.setVisible(false);
            heart.setVisible(true);
            Toast.makeText(this,
                    name+" was removed from favorites",
                    Toast.LENGTH_LONG).show();
            SharedPreferences pref = this.getSharedPreferences("MyPref", 0);
            SharedPreferences.Editor editor = pref.edit();
            if(pref.contains("key")) {
                keys = pref.getString("key", "").split(",");
                if (keys.length == 1)
                    pref.edit().remove("key").apply();
                else {
                    int i;
                    StringBuilder sb = new StringBuilder();
                    for (i = 0; i < keys.length; i++) {
                        if (!keys[i].equals(idd)) {
                            sb.append(keys[i]).append(",");
                        }
                    }
                    editor.putString("key",sb.toString() );
                    editor.commit();
                }
            }

            pref = this.getSharedPreferences("MyPref", 0);
            editor = pref.edit();
            if(pref.contains("fav")) {
                favs = pref.getString("fav", "").split(",");
                if (keys.length == 1)
                    pref.edit().remove("fav").commit();
                else {
                    int i;
                    StringBuilder sb = new StringBuilder();
                    i = 0;
                    while(i<favs.length){
                        if (!favs[i].equals(idd)) {
                            sb.append(favs[i]).append(",").append(favs[i+1]).append(",").append(favs[i+2]).append(",").append(favs[i+3]).append(",").append(favs[i+4]).append(",").append(favs[i+5]).append(",").append(favs[i+6]).append(",").append(favs[i+7]).append(",").append(favs[i+8]).append(",").append(favs[i+9]).append(",");
                        }
                        i+=10;
                    }
                    editor.putString("fav",sb.toString() );
                    editor.apply();
                }
            }

            return true;
        }
        if (id == R.id.twitter) {
            Uri uri = Uri.parse("https://twitter.com/intent/tweet?text=Check+out+"+name+"+located+at+"+venue+"+.+Website:+"+url+"&hashtags=CSCI571EventSearch");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            //return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public boolean onSupportNavigateUp() {
//        Intent i=new Intent(this,EventResult.class);
//        startActivity(i);
        if(back.equals("0")) {
            Intent i = new Intent(this, EventResult.class);
            i.putExtra("keyw", keyw);
            i.putExtra("category", category);
            i.putExtra("dista", dista);
            i.putExtra("lon", lon);
            i.putExtra("lat", lat);
            i.putExtra("otherloc", otherloc);
            startActivity(i);
        }
        else {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }
        return true;
    }
}
