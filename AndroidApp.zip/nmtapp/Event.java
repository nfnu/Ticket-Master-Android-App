package com.example.nisha.nmtapp;

public class Event {
    private String name,venue,date,time,img,id,url,artist1,artist2,segment,keyw,category,dista,typed,otherloc,lat,lon;

        /*public Movie() {
        }*/

    public Event(String name, String venue, String date, String time,String img,String id,String url,String artist1,String artist2,String segment,String keyw,String category,String dista,String typed,String otherloc,String lat,String lon) {
        this.name = name;
        this.venue = venue;
        this.date = date;
        this.time = time;
        this.img = img;
        this.id= id;
        this.url=url;
        this.artist1=artist1;
        this.artist2=artist2;
        this.keyw=keyw;
        this.category=category;
        this.dista=dista;
        this.typed=typed;
        this.otherloc=otherloc;
        this.lat=lat;
        this.lon=lon;
        this.segment=segment;
    }

    public String getKeyw() {
        return keyw;
    }

    public void setKeyw(String name) {
        this.keyw = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String name) {
        this.category = name;
    }

    public String getDista() {
        return dista;
    }

    public void setDista(String name) {
        this.dista = name;
    }

    public String getTyped() {
        return typed;
    }

    public void setTyped(String name) {
        this.typed = name;
    }

    public String getOtherloc() {
        return otherloc;
    }

    public void setOtherloc(String name) {
        this.otherloc = name;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String name) {
        this.lat = name;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String name) {
        this.lon = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String name) {
        this.segment = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String year) {
        this.date = year;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String genre) {
        this.venue = genre;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getArtist1() {
        return artist1;
    }

    public void setArtist1(String artist1) {
        this.artist1 = artist1;
    }

    public String getArtist2() {
        return artist2;
    }

    public void setArtist2(String artist2) {
        this.artist2 = artist2;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
