package com.example.nisha.nmtapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    double longitude,latitude;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActivityCompat.requestPermissions(MainActivity.this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                1);
        if ( ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED ) {
            Toast.makeText(this, "Please grant location permission", Toast.LENGTH_SHORT).show();
        }
        else {
            try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                longitude = location.getLongitude();
                latitude = location.getLatitude();
            }catch(NullPointerException e){
             longitude=-122.084;
             latitude=37.422;
            }
            //Toast.makeText(this, Double.toString(longitude), Toast.LENGTH_SHORT).show();
            Bundle bundle = new Bundle();
            bundle.putString("lon", Double.toString(longitude));
            bundle.putString("lat", Double.toString(latitude));

        }

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0);
//        pref.edit().remove("name").commit();// 0 - for private mode
//        SharedPreferences.Editor editor = pref.edit();
//
//        editor.putString("name", "string value"); // Storing string
//
//        editor.commit(); // commit changes

        final TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Search"));
        tabLayout.addTab(tabLayout.newTab().setText("Favorite"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount(),Double.toString(longitude),Double.toString(latitude));
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if ( ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED ) {
                        Toast.makeText(this, "Please grant location permission", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                        try {
                            Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                            longitude = location.getLongitude();
                            latitude = location.getLatitude();
                            //Toast.makeText(this, Double.toString(longitude), Toast.LENGTH_SHORT).show();

                        } catch(NullPointerException  e){
                            longitude=-118.283;
                            latitude=34.0266;
                        }
                        Bundle bundle = new Bundle();
                        bundle.putString("lon", Double.toString(longitude));
                        bundle.putString("lat", Double.toString(latitude));

                    }

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
