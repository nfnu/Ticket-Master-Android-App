package com.example.nisha.nmtapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class UpcomingTab extends Fragment {
    String id, venue, vid;
    View view;
    RecyclerView recyclerView;
    UpdateAdapter mAdapter;
    private List<Update> eventList = new ArrayList<>();
    TextView bu, sea, norec;
    LinearLayout ll;
    String[] values =
            {"Default", "Event Name", "Time", "Artist", "Type"};

    String[] values1 =
            {"Ascending", "Descending"};
    Spinner spinner,spinner1;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        id = getArguments().getString("id");
        venue = getArguments().getString("venue");
        view = inflater.inflate(R.layout.upcoming_tab, container, false);
        recyclerView = view.findViewById(R.id.recycler_view);
        spinner=view.findViewById(R.id.type);
        spinner1=view.findViewById(R.id.order);
        recyclerView.setVisibility(GONE);
        mAdapter = new UpdateAdapter(eventList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setEnabled(false);
        showupcoming(venue);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Boolean asc;
                if(spinner1.getSelectedItemPosition()==0)
                    asc=true;
                else
                    asc=false;
                if(position!=0)
                    spinner1.setEnabled(true);
                else
                    spinner1.setEnabled(false);
                if (position == 1) {
                    sortByDispname(asc);
                } else if (position == 3) {
                    sortByArtistname(asc);
                } else if (position == 4) {
                    sortByType(asc);
                } else if (position == 2) {
                    sortByDate(asc);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Boolean asc;
                if(position==0)
                    asc=true;
                else
                    asc=false;

                if (spinner.getSelectedItemPosition() == 1) {
                    sortByDispname(asc);
                } else if (spinner.getSelectedItemPosition() == 3) {
                    sortByArtistname(asc);
                } else if (spinner.getSelectedItemPosition() == 4) {
                    sortByType(asc);
                } else if (spinner.getSelectedItemPosition() == 2) {
                    sortByDate(asc);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }


    private void sortByDispname(boolean asc)
    {   Collections.sort(eventList,  (l1, l2) -> l1.getDispname().compareTo(l2.getDispname()));

        //SORT ARRAY ASCENDING AND DESCENDING
        if (!asc)
        {
            Collections.reverse(eventList);
        }

        //ADAPTER
        mAdapter = new UpdateAdapter(eventList);
        recyclerView.setAdapter(mAdapter);

    }

    private void sortByArtistname(boolean asc)
    {   Collections.sort(eventList,  (l1, l2) -> l1.getArtistname().compareTo(l2.getArtistname()));

        //SORT ARRAY ASCENDING AND DESCENDING
        if (!asc)
        {
            Collections.reverse(eventList);
        }

        //ADAPTER
        mAdapter = new UpdateAdapter(eventList);
        recyclerView.setAdapter(mAdapter);

    }

    private void sortByType(boolean asc)
    {   Collections.sort(eventList,  (l1, l2) -> l1.getType().compareTo(l2.getType()));

        //SORT ARRAY ASCENDING AND DESCENDING
        if (!asc)
        {
            Collections.reverse(eventList);
        }

        //ADAPTER
        mAdapter = new UpdateAdapter(eventList);
        recyclerView.setAdapter(mAdapter);

    }

    private void sortByDate(boolean asc)
    {   Collections.sort(eventList,  (l1, l2) -> l1.getDate().compareTo(l2.getDate()));

        //SORT ARRAY ASCENDING AND DESCENDING
        if (!asc)
        {
            Collections.reverse(eventList);
        }

        //ADAPTER
        mAdapter = new UpdateAdapter(eventList);
        recyclerView.setAdapter(mAdapter);

    }


    private void showupcoming(String venue) {
        class UpcShow extends AsyncTask<String, Void, String> {
            Context ctx;
            ProgressBar nDialog;
            String results,s;
            TextView msg = view.findViewById(R.id.msg);

            UpcShow(Context ctx) {
                this.ctx = ctx;
            }

            protected void onPreExecute() {
                super.onPreExecute();

                nDialog = view.findViewById(R.id.progress_loader);
                nDialog.setVisibility(VISIBLE);
                msg.setVisibility(VISIBLE);
            }

            @Override
            protected String doInBackground(String... strings) {
                String venue = strings[0];
                //Toast.makeText(ctx,id, Toast.LENGTH_LONG).show();
                try {

                    URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/venueid?venue=" + venue);
                    URLConnection jc = url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    s = reader.readLine();
                    try {
                        JSONObject jsonResponse = new JSONObject(s);
                        JSONArray jsonArray = jsonResponse.getJSONArray("results");
                        if (jsonArray.length() != 0) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject r = jsonArray.getJSONObject(i);
                                vid = r.getString("vid");
                            }
                        }
                    }catch (Exception e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }

                    url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/upcevents?vid=" + vid);
                    jc = url.openConnection();
                    reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    results = reader.readLine();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return results;
            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                nDialog.setVisibility(GONE);
                msg.setVisibility(GONE);
                recyclerView.setVisibility(VISIBLE);

                //Toast.makeText(ctx,s,Toast.LENGTH_LONG).show();

                try {
                    JSONObject jsonResponse = new JSONObject(s);
                    JSONArray jsonArray = jsonResponse.getJSONArray("results");
                    if(jsonArray.length()!=0) {
                        view.findViewById(R.id.spinner).setVisibility(VISIBLE);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject r = jsonArray.getJSONObject(i);
                            eventList.add(new Update(r.getString("dispname"), r.getString("artistname"), r.getString("update"), r.getString("uri"),r.getString("type"),r.getString("date")));
                            //Toast.makeText(ctx,r.getString("name"),Toast.LENGTH_LONG).show();
                        }
                        mAdapter.notifyDataSetChanged();
                        //sortData(true);
                    }
                    else {
                        norec = view.findViewById(R.id.norec);
                        norec.setVisibility(VISIBLE);
                        spinner1.setEnabled(false);
                        spinner.setEnabled(false);
                    }

                }catch (Exception e1) {
                    // TODO Auto-generated catch block
                    Toast.makeText(ctx, "Try again in some time.", Toast.LENGTH_SHORT).show();
                    e1.printStackTrace();
                }

            }
        }
            UpcShow ru = new UpcShow(view.getContext());
            ru.execute(venue);


    }
}