package com.example.nisha.nmtapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class ArtistTab extends Fragment {
    String id,artist1,artist2,segment;
    View view;
    TextView bu,sea,norec;
    private List<Artist> eventList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ArtistAdapter mAdapter;
    LinearLayout ll;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        id = getArguments().getString("id");
        artist1 = getArguments().getString("artist1");
        artist2 = getArguments().getString("artist2");
        segment = getArguments().getString("segment");
        //Toast.makeText(getContext(), artist2, Toast.LENGTH_SHORT).show();
        view = inflater.inflate(R.layout.artist_tab, container, false);
        //showartists(artist1,artist2);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        //recyclerView.setVisibility(GONE);
        mAdapter = new ArtistAdapter(eventList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        showartists(artist1,artist2,segment);
        return view;
    }

    private void showartists(String artist1,String artist2,String segment){
        class ArtistShow extends AsyncTask<String,Void, String> {
            Context ctx;
            String results;
            ProgressDialog loading;
            ProgressBar nDialog= view.findViewById(R.id.progress_loader);;
            TextView msg=view.findViewById(R.id.msg);
            ArtistShow(Context ctx)
            {
                this.ctx =ctx;
            }
            protected void onPreExecute(){
                super.onPreExecute();
            }

            @Override
            protected String doInBackground(String... strings) {
                String artist1 = strings[0];
                String artist2 = strings[1];
                String segment = strings[2];

                try {
                    URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/artists?artist1="+artist1+"&artist2="+artist2+"&segment="+segment);
                    URLConnection jc = url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    results = reader.readLine();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return results;


            }

            protected void onPostExecute(String s){
                super.onPostExecute(s);
                nDialog.setVisibility(GONE);
                msg.setVisibility(GONE);
                recyclerView.setVisibility(VISIBLE);
                //Toast.makeText(ctx,s,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonResponse = new JSONObject(s);
                    JSONArray jsonArray = jsonResponse.getJSONArray("results");
                    //Toast.makeText(ctx, "Here", Toast.LENGTH_SHORT).show();
                    if(jsonArray.length()!=0) {
                       for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject r = jsonArray.getJSONObject(i);
                            eventList.add(new Artist(r.getString("artistname"),r.getString("name"), r.getString("followers"), r.getString("popularity"), r.getString("spotify"),r.getString("imgsrc0"),r.getString("imgsrc1"),r.getString("imgsrc2"),r.getString("imgsrc3"),r.getString("imgsrc4"),r.getString("imgsrc5"),r.getString("imgsrc6"),r.getString("imgsrc7")));
                            //Toast.makeText(ctx,r.getString("artistname"),Toast.LENGTH_LONG).show();
                        }
                        mAdapter.notifyDataSetChanged();
                    }
                    else {
                        norec = view.findViewById(R.id.norec);
                        norec.setVisibility(VISIBLE);
                    }

                }catch (Exception e1) {
                    // TODO Auto-generated catch block
                    Toast.makeText(ctx, "Try again in some time.", Toast.LENGTH_SHORT).show();
                    e1.printStackTrace();
                }

            }
        }
        ArtistShow ru = new ArtistShow(view.getContext());
        ru.execute(artist1,artist2,segment);

    }




}



