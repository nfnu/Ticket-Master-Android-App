package com.example.nisha.nmtapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class PagerAdapter1 extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    String id,venue,artist1,artist2,segment;

    public PagerAdapter1(FragmentManager fm, int NumOfTabs, String id, String venue,String artist1,String artist2,  String segment) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
        this.id=id;
        this.venue=venue;
        this.artist1=artist1;
        this.artist2=artist2;
        this.segment=segment;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                EventTab tab1 = new EventTab();
                Bundle bundle = new Bundle();
                bundle.putString("id", id);
                tab1.setArguments(bundle);
                return tab1;
            case 1:
                ArtistTab tab2 = new ArtistTab();
                Bundle bundle1 = new Bundle();
                bundle1.putString("id", id);
                bundle1.putString("artist1", artist1);
                bundle1.putString("artist2", artist2);
                bundle1.putString("segment", segment);
                tab2.setArguments(bundle1);
                return tab2;
            case 2:
                VenueTab tab3 = new VenueTab();
                Bundle bundle2 = new Bundle();
                bundle2.putString("id", id);
                tab3.setArguments(bundle2);
                return tab3;
            case 3:
                UpcomingTab tab4 = new UpcomingTab();
                Bundle bundle3 = new Bundle();
                bundle3.putString("id", id);
                bundle3.putString("venue", venue);
                tab4.setArguments(bundle3);
                return tab4;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
