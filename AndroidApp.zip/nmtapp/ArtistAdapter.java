package com.example.nisha.nmtapp;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ArtistAdapter extends RecyclerView.Adapter<ArtistAdapter.MyViewHolder>{

    private List<Artist> moviesList;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView artistname,name,followers,popularity,spotify;
        public LinearLayout nam,follower,popularit,spotif;
        public ImageView imgsrc0,imgsrc1,imgsrc2,imgsrc3,imgsrc4,imgsrc5,imgsrc6,imgsrc7;
        String fav="0";
        public MyViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            artistname = (TextView) view.findViewById(R.id.artistname);
            name = (TextView) view.findViewById(R.id.aname);
            followers = (TextView) view.findViewById(R.id.followers);
            popularity = (TextView) view.findViewById(R.id.popularity);
            spotify = (TextView) view.findViewById(R.id.spotify);
            nam =  view.findViewById(R.id.nam);
            follower =  view.findViewById(R.id.follower);
            popularit =  view.findViewById(R.id.popularit);
            spotif =  view.findViewById(R.id.spotif);
            imgsrc0 = (ImageView) view.findViewById(R.id.imgsrc0);
            imgsrc1 = (ImageView) view.findViewById(R.id.imgsrc1);
            imgsrc2 = (ImageView) view.findViewById(R.id.imgsrc2);
            imgsrc3 = (ImageView) view.findViewById(R.id.imgsrc3);
            imgsrc4 = (ImageView) view.findViewById(R.id.imgsrc4);
            imgsrc5 = (ImageView) view.findViewById(R.id.imgsrc5);
            imgsrc6 = (ImageView) view.findViewById(R.id.imgsrc6);
            imgsrc7 = (ImageView) view.findViewById(R.id.imgsrc7);
        }


        @Override
        public void onClick(View v) {
            //Toast.makeText(v.getContext(), "Hi", Toast.LENGTH_SHORT).show();
//            Intent i=new Intent(v.getContext(),EventDetail.class);
//            i.putExtra("id",id.getText().toString());
//            i.putExtra("name",name.getText().toString());
//            i.putExtra("fav",fav);
//            i.putExtra("url",url.getText().toString());
//            i.putExtra("venue",venue.getText().toString());
//            i.putExtra("artist1",artist1.getText().toString());
//            i.putExtra("artist2",artist2.getText().toString());
//            v.getContext().startActivity(i);
        }
    }



    public ArtistAdapter(List<Artist> moviesList) {
        this.moviesList = moviesList;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.artist_list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ArtistAdapter.MyViewHolder holder, int position) {
        Artist movie = moviesList.get(position);
        //Toast.makeText(view.getContext(), "", Toast.LENGTH_SHORT).show();
        if(!movie.getArtistname().equals("")) {
            holder.artistname.setText(movie.getArtistname());
            holder.artistname.setVisibility(View.VISIBLE);
        }
        if(!movie.getName().equals("")) {
            holder.name.setText(movie.getName());
            holder.nam.setVisibility(View.VISIBLE);
        }
        if(!movie.getPopularity().equals("")) {
            holder.popularity.setText(movie.getPopularity());
            holder.popularit.setVisibility(View.VISIBLE);
        }
        if(!movie.getFollowers().equals("")) {
            holder.followers.setText(movie.getFollowers());
            holder.follower.setVisibility(View.VISIBLE);
        }
        if(!movie.getSpotify().equals("")) {
            //holder.spotify.setText("Spotify");
            holder.spotif.setVisibility(View.VISIBLE);
            SpannableString content = new SpannableString("Spotify");
            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
            holder.spotify.setText(content);
            holder.spotify.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v)
                {
                    Uri uri = Uri.parse(movie.getSpotify());
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    v.getContext().startActivity(intent);
                }
            });
        }
        if(!movie.getImgsrc0().equals("")) {
            Picasso.get().load(movie.getImgsrc0()).into(holder.imgsrc0);
            holder.imgsrc0.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc1().equals("")){
        Picasso.get().load(movie.getImgsrc1()).into(holder.imgsrc1);
            holder.imgsrc1.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc2().equals("")){
        Picasso.get().load(movie.getImgsrc2()).into(holder.imgsrc2);
            holder.imgsrc2.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc3().equals("")){
        Picasso.get().load(movie.getImgsrc3()).into(holder.imgsrc3);
            holder.imgsrc3.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc4().equals("")){
        Picasso.get().load(movie.getImgsrc4()).into(holder.imgsrc4);
            holder.imgsrc4.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc5().equals("")){
        Picasso.get().load(movie.getImgsrc5()).into(holder.imgsrc5);
            holder.imgsrc5.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc6().equals("")){
        Picasso.get().load(movie.getImgsrc6()).into(holder.imgsrc6);
            holder.imgsrc6.setVisibility(View.VISIBLE);
        }
        if(!movie.getImgsrc7().equals("")){
        Picasso.get().load(movie.getImgsrc7()).into(holder.imgsrc7);
            holder.imgsrc7.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}
