package com.example.nisha.nmtapp;

public class Artist {
    private String artistname,followers,popularity,spotify,imgsrc0,imgsrc1,imgsrc2,imgsrc3,imgsrc4,imgsrc5,imgsrc6,imgsrc7,name;

        /*public Movie() {
        }*/

    public Artist(String artistname, String name, String followers, String popularity, String spotify, String imgsrc0, String imgsrc1, String imgsrc2, String imgsrc3, String imgsrc4, String imgsrc5, String imgsrc6, String imgsrc7) {
        this.artistname = artistname;
        this.followers = followers;
        this.name=name;
        this.popularity = popularity;
        this.spotify = spotify;
        this.imgsrc0 = imgsrc0;
        this.imgsrc1 = imgsrc1;
        this.imgsrc2 = imgsrc2;
        this.imgsrc3 = imgsrc3;
        this.imgsrc4 = imgsrc4;
        this.imgsrc5 = imgsrc5;
        this.imgsrc6 = imgsrc6;
        this.imgsrc7 = imgsrc7;
    }

    public String getArtistname() {
        return artistname;
    }

    public void setArtistname(String name) {
        this.artistname = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFollowers() {
        return followers;
    }

    public void setFollowers(String followers) {
        this.followers = followers;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getSpotify() {
        return spotify;
    }

    public void setSpotify(String spotify) {
        this.spotify = spotify;
    }

    public String getImgsrc0() {
        return imgsrc0;
    }

    public void setImgsrc0(String img) {
        this.imgsrc0 = img;
    }

    public String getImgsrc1() {
        return imgsrc1;
    }

    public void setImgsrc1(String img) {
        this.imgsrc1 = img;
    }

    public String getImgsrc2() {
        return imgsrc2;
    }

    public void setImgsrc2(String img) {
        this.imgsrc2 = img;
    }

    public String getImgsrc3() {
        return imgsrc3;
    }

    public void setImgsrc3(String img) {
        this.imgsrc3 = img;
    }

    public String getImgsrc4() {
        return imgsrc4;
    }

    public void setImgsrc4(String img) {
        this.imgsrc4= img;
    }

    public String getImgsrc5() {
        return imgsrc5;
    }

    public void setImgsrc5(String img) {
        this.imgsrc5 = img;
    }

    public String getImgsrc6() {
        return imgsrc6;
    }

    public void setImgsrc6(String img) {
        this.imgsrc6 = img;
    }

    public String getImgsrc7() {
        return imgsrc7;
    }

    public void setImgsrc7(String img) {
        this.imgsrc7 = img;
    }

    }
