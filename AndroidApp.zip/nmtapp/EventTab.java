package com.example.nisha.nmtapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class EventTab extends Fragment {
    String id;
    View view;
    TextView artis,venu,dat,categor,pric,ticke,bu,sea,norec;
    LinearLayout ll;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        id = getArguments().getString("id");
        view = inflater.inflate(R.layout.event_tab, container, false);
        artis=view.findViewById(R.id.artist);
        venu=view.findViewById(R.id.venue);
        dat=view.findViewById(R.id.date);
        categor=view.findViewById(R.id.category);
        pric=view.findViewById(R.id.price);
        ticke=view.findViewById(R.id.ticket);
        bu=view.findViewById(R.id.buy);

        sea=view.findViewById(R.id.seat);
        ll=view.findViewById(R.id.art);
        //Toast.makeText(getContext(), artis.getText().toString(), Toast.LENGTH_SHORT).show();
        ll.setVisibility(GONE);
        view.findViewById(R.id.ven).setVisibility(GONE);
        view.findViewById(R.id.tim).setVisibility(GONE);
        view.findViewById(R.id.cat).setVisibility(GONE);
        view.findViewById(R.id.pri).setVisibility(GONE);
        view.findViewById(R.id.tick).setVisibility(GONE);
        view.findViewById(R.id.bu).setVisibility(GONE);
        view.findViewById(R.id.sea).setVisibility(GONE);
        showdetails(id);
        return view;
    }


    private void showdetails(String id){
        class EventShow extends AsyncTask<String,Void, String> {
            Context ctx;
            String results,artist,venue,date,category,price,ticket,buy,seat;
            ProgressBar nDialog;
            TextView msg=view.findViewById(R.id.msg);
            EventShow(Context ctx)
            {
                this.ctx =ctx;
            }
            protected void onPreExecute(){
                super.onPreExecute();

                nDialog = view.findViewById(R.id.progress_loader);
                nDialog.setVisibility(VISIBLE);
                msg.setVisibility(VISIBLE);

                //listView.setVisibility(VISIBLE);

            }

            @Override
            protected String doInBackground(String... strings) {
                String id = strings[0];
                //Toast.makeText(ctx,id, Toast.LENGTH_LONG).show();
                try {

                    //URL url = new URL("http://10.0.2.2:3000/details?id="+id);
                    URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/details?id="+id);
                    //Toast.makeText(ctx,url.toString(), Toast.LENGTH_LONG).show();
                    URLConnection jc = url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    results = reader.readLine();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return results;


            }

            protected void onPostExecute(String s){
                super.onPostExecute(s);
                nDialog.setVisibility(GONE);
                msg.setVisibility(GONE);
                //Toast.makeText(ctx,s,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonResponse = new JSONObject(s);
                    JSONArray jsonArray = jsonResponse.getJSONArray("results");
                    if(jsonArray.length()!=0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject r = jsonArray.getJSONObject(i);
                            artist=r.getString("artist");
                            venue=r.getString("venue");
                            date=r.getString("date");
                            category=r.getString("category");
                            price=r.getString("price");
                            ticket=r.getString("ticket");
                            buy=r.getString("buy");
                            seat=r.getString("seat");
                            //Toast.makeText(ctx,r.getString("name"),Toast.LENGTH_LONG).show();
                        }
                    }
                    if(artist.equals("") && venue.equals("") && date.equals("") && category.equals("") && price.equals("") && ticket.equals("") && buy.equals("") && seat.equals(""))
                    {
                        norec = view.findViewById(R.id.norec);
                        norec.setVisibility(VISIBLE);
                    }
                    else{
                        if(!artist.equals("")){
                            LinearLayout ll=view.findViewById(R.id.art);
                            ll.setVisibility(VISIBLE);
                            artis.setText(artist);
                        }
                        if(!venue.equals("")){
                            LinearLayout ll=view.findViewById(R.id.ven);
                            ll.setVisibility(VISIBLE);
                            venu.setText(venue);
                        }
                        if(!date.equals("")){
                            LinearLayout ll=view.findViewById(R.id.tim);
                            ll.setVisibility(VISIBLE);
                            dat.setText(date);
                        }
                        if(!category.equals("")){
                            LinearLayout ll=view.findViewById(R.id.cat);
                            ll.setVisibility(VISIBLE);
                            categor.setText(category);
                        }
                        if(!price.equals("")){
                            LinearLayout ll=view.findViewById(R.id.pri);
                            ll.setVisibility(VISIBLE);
                            pric.setText(price);
                        }
                        if(!buy.equals("")){
                            LinearLayout ll=view.findViewById(R.id.tick);
                            ll.setVisibility(VISIBLE);
                            ticke.setText(buy);
                        }
                        if(!ticket.equals("")){
                            LinearLayout ll=view.findViewById(R.id.bu);
                            ll.setVisibility(VISIBLE);
                            SpannableString content = new SpannableString("Ticketmaster");
                            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                            bu.setText(content);
                            bu.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v)
                                {
                                    Uri uri = Uri.parse(ticket);
                                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                    startActivity(intent);
                                }
                            });

                        }
                        if(!seat.equals("")){
                            LinearLayout ll=view.findViewById(R.id.sea);
                            ll.setVisibility(VISIBLE);
                            SpannableString content = new SpannableString("View Here");
                            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                            sea.setText(content);
                            sea.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v)
                                {
                                    Uri uri = Uri.parse(seat);
                                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                    startActivity(intent);

                                }
                            });
                        }

                    }

                }catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }
        EventShow ru = new EventShow(view.getContext());
        ru.execute(id);

    }



}
