package com.example.nisha.nmtapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.widget.Toast;

public class PagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    String lon, lat;

    public PagerAdapter(FragmentManager fm, int NumOfTabs,String lon,String lat) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
        this.lon=lon;
        this.lat=lat;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                SearchTab tab1 = new SearchTab();
                Bundle bundle = new Bundle();
                bundle.putString("lon", lon);
                bundle.putString("lat", lat);
                tab1.setArguments(bundle);
                return tab1;
            case 1:
                FavTab tab2 = new FavTab();
                Bundle bundle1 = new Bundle();
                bundle1.putString("lon", lon);
                bundle1.putString("lat", lat);
                tab2.setArguments(bundle1);
                return tab2;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}