package com.example.nisha.nmtapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;

public class SearchTab extends Fragment {
    TextView error1,error2;
    RadioButton rb1, rb2;
    View view;
    AutoCompleteTextView key;
    EditText dist,other;
    Spinner spinner,spinner1;
    String category,typed,keyw,dista,otherloc;
    RadioGroup rad;
    String lon,lat;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        lon = getArguments().getString("lon");
        lat = getArguments().getString("lat");
        //Toast.makeText(getContext(), lon, Toast.LENGTH_SHORT).show();
        view = inflater.inflate(R.layout.search_tab, container, false);
        String[] values =
                {"All", "Music", "Sports", "Arts & Theatre", "Film", "Miscellaneous"};

        String[] values1 =
                {"Miles", "Kilometers"};

        key=view.findViewById(R.id.keyword);
        dist=view.findViewById(R.id.distance);
        other=view.findViewById(R.id.other);
        spinner = view.findViewById(R.id.category);
// Create an ArrayAdapter using the string array and a default spinner layout
        error1=view.findViewById(R.id.error1);
        error2=view.findViewById(R.id.error2);

        error1.setVisibility(View.GONE);
        error2.setVisibility(View.GONE);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

// Specify the layout to use when the list of choices appears

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner1 = view.findViewById(R.id.dtype);
// Create an ArrayAdapter using the string array and a default spinner layout

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

// Specify the layout to use when the list of choices appears

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner1.setAdapter(adapter1);
        rb1 = view.findViewById(R.id.current);
        rb2 = view.findViewById(R.id.another);
        rb1.setChecked(true);
        rb2.setChecked(false);

         key = view.findViewById(R.id.keyword);
      key.setAdapter(new SuggestionAdapter(getActivity(),key.getText().toString()));



        category=spinner.getSelectedItem().toString();
        typed=spinner1.getSelectedItem().toString();
        keyw=key.getText().toString();
        dista=dist.getText().toString();
        otherloc=other.getText().toString();
        other.setEnabled(false);
        rad=view.findViewById(R.id.rag);
        rad.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int id=rad.getCheckedRadioButtonId();
                View radioButton = rad.findViewById(id);
                if(radioButton.getId()==R.id.another)
                {
                    other.setEnabled(true);
                }
                else
                {
                    other.setEnabled(false);
                    other.setText("");
                }
            }
        });


        Button search = view.findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                    keyw=key.getText().toString();
                otherloc=other.getText().toString();
                    //Toast.makeText(getContext(),keyw,Toast.LENGTH_LONG).show();
                if(keyw.equals("") || (rb2.isChecked() && otherloc.equals(""))) {
                    if (keyw.equals("")) {

                        error1.setVisibility(View.VISIBLE);
                    } else {
                        error1.setVisibility(View.GONE);
                    }
                    if (rb2.isChecked() && otherloc.equals("")) {
                        error2.setVisibility(View.VISIBLE);
                    } else {
                        error2.setVisibility(View.GONE);
                    }
                    Toast.makeText(getContext(),"Please fix all fields with errors",Toast.LENGTH_LONG).show();
                }
                else{
                    error1.setVisibility(View.GONE);
                    error2.setVisibility(View.GONE);
                    category=spinner.getSelectedItem().toString();
                    typed=spinner1.getSelectedItem().toString();
                    keyw=key.getText().toString();
                    dista=dist.getText().toString();
                    otherloc=other.getText().toString();
                    if(dista.equals(""))
                        dista="10";
                    //showevents(keyw,category,dista,typed,otherloc);
                    Intent i=new Intent(getActivity(),EventResult.class);
                    i.putExtra("keyw",keyw);
                    i.putExtra("category",category);
                    i.putExtra("dista",dista);
                    i.putExtra("typed",typed);
                    i.putExtra("lon",lon);
                    i.putExtra("lat",lat);
                    i.putExtra("otherloc",otherloc);
                    startActivity(i);
                }
                }

        });


        Button clear = view.findViewById(R.id.clear);
        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                key.setText("");
                dist.setText("");
                other.setText("");
                spinner1.setSelection(0);
                spinner.setSelection(0);
                rb1.setChecked(true);
                rb2.setChecked(false);
                error1.setVisibility(View.GONE);
                error2.setVisibility(View.GONE);
            }
        });

        return view;
    }

//    private void showevents(String keyw,String cate,String dist,String dty, String otherlo){
//        class EventShow extends AsyncTask<String,Void, String>{
//            Context ctx;
//            String results;
//            ProgressDialog loading;
//            EventShow(Context ctx)
//            {
//                this.ctx =ctx;
//            }
//            protected void onPreExecute(){
//                super.onPreExecute();
//                Intent i=new Intent(getActivity(),EventResult.class);
//                startActivity(i);
//                loading = ProgressDialog.show(getActivity(), "Please Wait", null, true, true);
//            }
//
//            @Override
//            protected String doInBackground(String... strings) {
//                String keyword = strings[0];
//                String category = strings[1];
//                String distance = strings[2];
//                String dtype = strings[3];
//                String otherloc = strings[4];
//
//                try {
//                    URL url = new URL("http://10.0.2.2:3000/events?keyword="+keyword+"&category="+category+"&distance="+distance+"&dtype="+dtype+"&otherloc="+otherloc);
//                    URLConnection jc = url.openConnection();
////                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
//
////                    httpURLConnection.setRequestMethod("GET");
////                    httpURLConnection.setDoOutput(true);
////                    //httpURLConnection.setDoInput(true);
////                    OutputStream OS = httpURLConnection.getOutputStream();
////
////
////                     BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
////                    String data = URLEncoder.encode("keyword", "UTF-8") + "=" + URLEncoder.encode(keyword, "UTF-8") + "&" +
////                            URLEncoder.encode("category", "UTF-8") + "=" + URLEncoder.encode(category, "UTF-8");
////                    bufferedWriter.write(data);
////                    bufferedWriter.flush();
////                    bufferedWriter.close();
////                    OS.close();
//
//                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
//                    results = reader.readLine();
//
////                    InputStream IS = httpURLConnection.getInputStream();
////                    BufferedReader br = new BufferedReader(new InputStreamReader(IS));
////                    results = br.readLine();
////                    IS.close();
////                    //httpURLConnection.connect();
////                    httpURLConnection.disconnect();
////                    //return "Registration Success...";
//
//                } catch (MalformedURLException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                return results;
//
//
//            }
//
//            protected void onPostExecute(String s){
//                super.onPostExecute(s);
//                loading.dismiss();
//                Toast.makeText(getContext(),s,Toast.LENGTH_LONG).show();
//            }
//        }
//        EventShow ru = new EventShow(getContext());
//        ru.execute(keyw,cate,dist,dty,otherlo);
//
//    }

}
