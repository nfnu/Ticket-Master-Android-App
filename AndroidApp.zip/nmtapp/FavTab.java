package com.example.nisha.nmtapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class FavTab extends Fragment {
    String tr;
    View view;
    String[] favt;
    String[] keyt;
    String[] fav;
    private List<Event> eventList = new ArrayList<>();
    private RecyclerView recyclerView;
    private FavAdapter mAdapter;
    SharedPreferences pref;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view=inflater.inflate(R.layout.fav_tab, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setVisibility(GONE);
        mAdapter = new FavAdapter(eventList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        if(mAdapter.getItemCount()==0)
            view.findViewById(R.id.norec).setVisibility(VISIBLE);
        eventList.clear();
        mAdapter.notifyDataSetChanged();
        check();
        return view;
    }

    public void check() {
            pref = view.getContext().getSharedPreferences("MyPref",
                    Context.MODE_PRIVATE);
            if (pref.contains("key")) {
                eventList.clear();
                mAdapter.notifyDataSetChanged();
                tr = pref.getString("fav", ""); // getting String
                //Toast.makeText(view.getContext(), tr, Toast.LENGTH_LONG).show();

                recyclerView.setVisibility(VISIBLE);
                favt = pref.getString("fav", "").split(",");
                //keyt = pref.getString("key", "").split(",");
                int i;
                //Toast.makeText(view.getContext(), favt[0], Toast.LENGTH_SHORT).show();

                i = 0;
                while (i < favt.length) {
                    eventList.add(new Event(favt[i + 1], favt[i + 2], favt[i + 3], favt[i + 4], favt[i + 8], favt[i], favt[i + 9], favt[i + 5], favt[i + 6], favt[i + 7], "", "", "", "", "", "", ""));
                    //Toast.makeText(view.getContext(), favt[0], Toast.LENGTH_SHORT).show();
                    i += 10;
                }
                //Toast.makeText(getContext(),sb.toString(), Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                view.findViewById(R.id.norec).setVisibility(GONE);
            } else {
                view.findViewById(R.id.norec).setVisibility(VISIBLE);
            }
        }

}
