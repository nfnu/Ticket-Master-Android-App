package com.example.nisha.nmtapp;

public class Update{
    private String dispname, artistname,update, uri,type,date;

        /*public Movie() {
        }*/

        public Update(String dispname, String artistname, String update, String uri,String type,String date) {
            this.dispname = dispname;
            this.artistname = artistname;
            this.update = update;
            this.type = type;
            this.uri = uri;
            this.date=date;
        }

        public String getDispname() {
            return dispname;
        }

        public void setDispname(String name) {
            this.dispname = name;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getUpdate() {
            return update;
        }

        public void setUpdate(String update) {
            this.update = update;
        }

        public String getArtistname() {
            return artistname;
        }

        public void setArtistname(String artistname) {
            this.artistname = artistname;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getUri() {
            return uri;
        }

        public void setUri(String uri) {
            this.uri = uri;
        }
}
