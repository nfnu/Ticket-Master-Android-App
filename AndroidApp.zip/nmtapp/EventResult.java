package com.example.nisha.nmtapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class EventResult extends AppCompatActivity {
    String keyw,category,dista,typed,otherloc,lat,lon;
    private List<Event> eventList = new ArrayList<>();
    private RecyclerView recyclerView;
    private EventAdapter mAdapter;
    TextView norec;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_result);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setVisibility(GONE);
        mAdapter = new EventAdapter(eventList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            try {
                keyw = extras.getString("keyw");
                category = extras.getString("category");
                dista = extras.getString("dista");
                typed = extras.getString("typed");
                lon = extras.getString("lon");
                lat = extras.getString("lat");
                otherloc = extras.getString("otherloc");
            }catch(NullPointerException  e) {
                Toast.makeText(this,"Exception",Toast.LENGTH_LONG).show();
            }

        }

        showevents(keyw,category,dista,typed,otherloc);

    }

    public boolean onSupportNavigateUp() {
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
        onBackPressed();
        return true;
    }

    private void showevents(String keyw,String cate,String dist,String dty, String otherlo){

       class EventShow extends AsyncTask<String,Void, String> {
            Context ctx;
            String results;
            ProgressDialog loading;
            ProgressBar nDialog;
            TextView msg=findViewById(R.id.msg);
            EventShow(Context ctx)
            {
                this.ctx =ctx;
            }
            protected void onPreExecute(){
                super.onPreExecute();

                nDialog = findViewById(R.id.progress_loader);
                //listView.setVisibility(VISIBLE);

            }

            @Override
            protected String doInBackground(String... strings) {
                String keyword = strings[0];
                String category = strings[1];
                String distance = strings[2];
                String dtype = strings[3];
                String otherloc = strings[4];
                if(!otherloc.equals("")) {
                    try {
                        URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/otherlo?otherloc=" + otherloc);
                        URLConnection jc = url.openConnection();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                        results = reader.readLine();

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        JSONObject jsonResponse = new JSONObject(results);
                        JSONArray jsonArray = jsonResponse.getJSONArray("results");
                        if (jsonArray.length() != 0) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject r = jsonArray.getJSONObject(i);
                                lon=r.getString("lon");
                                lat=r.getString("lat");
                        }

                    }} catch (Exception e1) {

                    }
                }


                try {
                    URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/events?keyword="+keyword+"&category="+category+"&distance="+distance+"&dtype="+dtype+"&otherloc="+otherloc+"&lat="+lat+"&lon="+lon);
                    URLConnection jc = url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    results = reader.readLine();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return results;


            }

            protected void onPostExecute(String s){
                super.onPostExecute(s);
                nDialog.setVisibility(GONE);
                msg.setVisibility(GONE);
                recyclerView.setVisibility(VISIBLE);
                //Toast.makeText(ctx,s,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonResponse = new JSONObject(s);
                    JSONArray jsonArray = jsonResponse.getJSONArray("results");
                    if(jsonArray.length()!=0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject r = jsonArray.getJSONObject(i);
                            eventList.add(new Event(r.getString("name"), r.getString("venue"), r.getString("date"), r.getString("time"),r.getString("img"),r.getString("id"),r.getString("url"),r.getString("artist1"),r.getString("artist2"),r.getString("segment"),keyw,category,dista,typed,otherloc,lat,lon));
                            //Toast.makeText(ctx,r.getString("name"),Toast.LENGTH_LONG).show();
                        }
                        mAdapter.notifyDataSetChanged();
                    }
                    else {
                        norec = findViewById(R.id.norec);
                        norec.setVisibility(VISIBLE);
                    }

                }catch (Exception e1) {
                    // TODO Auto-generated catch block
                    Toast.makeText(ctx, "Try again in some time.", Toast.LENGTH_SHORT).show();
                    Intent i =new Intent(EventResult.this,MainActivity.class);
                    startActivity(i);
                    e1.printStackTrace();
                }

            }
        }
        EventShow ru = new EventShow(this);
        ru.execute(keyw,cate,dist,dty,otherlo);

    }

}
