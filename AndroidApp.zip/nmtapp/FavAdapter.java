package com.example.nisha.nmtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

public class FavAdapter extends RecyclerView.Adapter<FavAdapter.MyViewHolder>{
    private List<Event> moviesList;
    String[] keys,favs;
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name,venue,date,time,id,url,artist1,artist2,segment,keyw,category,dista,typed,otherloc,lat,lon;
        public ImageView img,imgheart,imgheartfill;
        String fav="0";
        public MyViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            name = (TextView) view.findViewById(R.id.name);
            venue = (TextView) view.findViewById(R.id.venue);
            date = (TextView) view.findViewById(R.id.date);
            time = (TextView) view.findViewById(R.id.time);
            id = (TextView) view.findViewById(R.id.id);
            img = (ImageView) view.findViewById(R.id.img);
            artist1 = (TextView) view.findViewById(R.id.artist1);
            segment = (TextView) view.findViewById(R.id.segment);
            artist2 = (TextView) view.findViewById(R.id.artist2);
            keyw = (TextView) view.findViewById(R.id.keyw);
            category = (TextView) view.findViewById(R.id.category);
            dista = (TextView) view.findViewById(R.id.dista);
            typed = (TextView) view.findViewById(R.id.typed);
            otherloc = (TextView) view.findViewById(R.id.otherloc);
            lat = (TextView) view.findViewById(R.id.lat);
            lon = (TextView) view.findViewById(R.id.lon);
            imgheartfill = (ImageView) view.findViewById(R.id.imgheartfill);
            url = (TextView) view.findViewById(R.id.url);
            imgheartfill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0);
                    SharedPreferences.Editor editor = pref.edit();
                    if (pref.contains("key")) {
                        keys = pref.getString("key", "").split(",");
                        if (keys.length == 1)
                            pref.edit().remove("key").commit();
                        else {
                            int i;
                            StringBuilder sb = new StringBuilder();
                            for (i = 0; i < keys.length; i++) {
                                if (!keys[i].equals(id.getText().toString())) {
                                    sb.append(keys[i]).append(",");
                                }
                            }
                            editor.putString("key", sb.toString());

                        }
                        editor.commit();
                    }
                    pref = v.getContext().getSharedPreferences("MyPref", 0);
                    editor = pref.edit();
                    if (pref.contains("fav")) {
                        favs = pref.getString("fav", "").split(",");

                            int i;
                            StringBuilder sb = new StringBuilder();
                            i = 0;
                            while (i < favs.length) {
                                if (!favs[i].equals(id.getText().toString())) {
                                    sb.append(favs[i]).append(",").append(favs[i + 1]).append(",").append(favs[i + 2]).append(",").append(favs[i + 3]).append(",").append(favs[i + 4]).append(",").append(favs[i + 5]).append(",").append(favs[i + 6]).append(",").append(favs[i + 7]).append(",").append(favs[i + 8]).append(",").append(favs[i + 9]).append(",");
                                }
                                i += 10;
                            }
                            editor.putString("fav", sb.toString());
                            editor.commit();

                    }
                    Toast.makeText(v.getContext(),
                            name.getText().toString() + " was removed from favorites",
                            Toast.LENGTH_LONG).show();
                    Intent i=new Intent(v.getContext(),MainActivity.class);
                    v.getContext().startActivity(i);

                    //removeAt(getPosition());
                }


            });
        }
        public void removeAt(int position) {
            moviesList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, moviesList.size());

        }

        @Override
        public void onClick(View v) {
            Intent i=new Intent(v.getContext(),EventDetail.class);
            i.putExtra("id",id.getText().toString());
            i.putExtra("name",name.getText().toString());
            i.putExtra("fav",fav);
            i.putExtra("url",url.getText().toString());
            i.putExtra("venue",venue.getText().toString());
            i.putExtra("artist1",artist1.getText().toString());
            i.putExtra("artist2",artist2.getText().toString());
            i.putExtra("segment",segment.getText().toString());
            i.putExtra("keyw",keyw.getText().toString());
            i.putExtra("category",category.getText().toString());
            i.putExtra("dista",dista.getText().toString());
            i.putExtra("lon",lon.getText().toString());
            i.putExtra("lat",lat.getText().toString());
            i.putExtra("back","1 ");
            i.putExtra("otherloc",otherloc.getText().toString());
            v.getContext().startActivity(i);



        }
    }

    public FavAdapter(List<Event> moviesList) {
        this.moviesList = moviesList;
    }

    @NonNull
    @Override
    public FavAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fav_list_row, parent, false);

        return new FavAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull FavAdapter.MyViewHolder holder, int position) {
        Event movie = moviesList.get(position);
        holder.name.setText(movie.getName());
        holder.venue.setText(movie.getVenue());
        holder.date.setText(movie.getDate());
        holder.time.setText(movie.getTime());
        holder.id.setText(movie.getId());
        holder.url.setText(movie.getUrl());
        holder.artist1.setText(movie.getArtist1());
        holder.artist2.setText(movie.getArtist2());
        holder.segment.setText(movie.getSegment());
        holder.keyw.setText(movie.getKeyw());
        holder.category.setText(movie.getCategory());
        holder.typed.setText(movie.getTyped());
        holder.lon.setText(movie.getLon());
        holder.lat.setText(movie.getLat());
        holder.otherloc.setText(movie.getOtherloc());
        holder.dista.setText(movie.getDista());
        Picasso.get().load(movie.getImg()).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}
