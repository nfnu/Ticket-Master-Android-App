package com.example.nisha.nmtapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class VenueTab extends Fragment implements OnMapReadyCallback {
    String id,lon,lat;
    View view;
    private GoogleMap mMap;
    TextView nam,addres,cit,phon,ope,grul,crul,norec;
    SupportMapFragment mapFragment;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        id = getArguments().getString("id");
        view = inflater.inflate(R.layout.venue_tab, container, false);

        mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        try {
            mapFragment.getView().setVisibility(View.GONE);
        }
        catch (Exception e) {
            e.printStackTrace ();
        }
        mapFragment.getMapAsync(this);
        nam=view.findViewById(R.id.name);
        addres=view.findViewById(R.id.address);
        cit=view.findViewById(R.id.city);
        phon=view.findViewById(R.id.phone);
        ope=view.findViewById(R.id.open);
        grul=view.findViewById(R.id.grule);
        crul=view.findViewById(R.id.crule);
        norec=view.findViewById(R.id.norec);
        showvenue(id);
        return view;
    }

    private void showvenue(String id) {
        class VenueShow extends AsyncTask<String, Void, String> {
            Context ctx;
            String results,venue,address,city,phone,op,grule,crule;
            ProgressBar nDialog;
            TextView msg=view.findViewById(R.id.msg);
            VenueShow(Context ctx)
            {
                this.ctx =ctx;
            }
            protected void onPreExecute(){
                super.onPreExecute();
                nDialog = view.findViewById(R.id.progress_loader);
                nDialog.setVisibility(VISIBLE);
                msg.setVisibility(VISIBLE);
            }

            @Override
            protected String doInBackground(String... strings) {
                String id = strings[0];
                //Toast.makeText(ctx,id, Toast.LENGTH_LONG).show();
                try {

                    URL url = new URL("http://nmtapp-env.np3yrbgpbn.us-east-2.elasticbeanstalk.com/venue?id="+id);
                    //Toast.makeText(ctx,url.toString(), Toast.LENGTH_LONG).show();
                    URLConnection jc = url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    results = reader.readLine();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return results;


            }

            protected void onPostExecute(String s){
                super.onPostExecute(s);
                nDialog.setVisibility(GONE);
                msg.setVisibility(GONE);
                //Toast.makeText(ctx,s,Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonResponse = new JSONObject(s);
                    JSONArray jsonArray = jsonResponse.getJSONArray("results");
                    if(jsonArray.length()!=0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject r = jsonArray.getJSONObject(i);
                            address=r.getString("address");
                            venue=r.getString("venue");
                            city=r.getString("city");
                            op=r.getString("op");
                            phone=r.getString("phone");
                            grule=r.getString("grule");
                            crule=r.getString("crule");
                            lon=r.getString("lon");
                            lat=r.getString("lat");
                        }
                    }
                    if(address.equals("") && lon.equals("") && lat.equals("") && venue.equals("") && city.equals("") && op.equals("") && phone.equals("") && grule.equals("") && crule.equals(""))
                    {
                        norec = view.findViewById(R.id.norec);
                        norec.setVisibility(VISIBLE);
                    }
                    else {
                        if (!venue.equals("")) {
                            view.findViewById(R.id.nam).setVisibility(VISIBLE);
                            nam.setText(venue);
                        }
                        if (!address.equals("")) {
                            view.findViewById(R.id.add).setVisibility(VISIBLE);
                            addres.setText(address);
                        }
                        if (!city.equals("")) {
                            view.findViewById(R.id.cit).setVisibility(VISIBLE);
                            cit.setText(city);
                        }
                        if (!phone.equals("")) {
                            view.findViewById(R.id.pho).setVisibility(VISIBLE);
                            phon.setText(phone);
                        }
                        if (!op.equals("")) {
                            view.findViewById(R.id.ope).setVisibility(VISIBLE);
                            ope.setText(op);
                        }
                        if (!grule.equals("")) {
                            view.findViewById(R.id.grul).setVisibility(VISIBLE);
                            grul.setText(grule);
                        }
                        if (!crule.equals("")) {
                            view.findViewById(R.id.crul).setVisibility(VISIBLE);
                            crul.setText(crule);
                        }
                        try {
                            LatLng mark=new LatLng(Double.valueOf(lat), Double.valueOf(lon));
                            MarkerOptions marker = new MarkerOptions().position(mark);
                            mMap.addMarker(marker);
                            mMap.moveCamera(CameraUpdateFactory.newLatLng(mark));
                            mapFragment.getView().setVisibility(View.VISIBLE);
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mark, 15.0f));
                        }
                        catch (Exception e) {
                            e.printStackTrace ();
                        }
                    }
                    } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }
        VenueShow ru = new VenueShow(view.getContext());
        ru.execute(id);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

    }
}
